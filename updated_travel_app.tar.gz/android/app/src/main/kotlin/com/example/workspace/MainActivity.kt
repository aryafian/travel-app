package com.example.workspace

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
